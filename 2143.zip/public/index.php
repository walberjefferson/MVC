<?php

require_once '../vendor/autoload.php';

$bootstrap = new \App\Init;